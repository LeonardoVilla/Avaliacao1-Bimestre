<?php

$servidor = "";
$banco = "bd_escola";
$usuario = "";
$senha = "";

try{
    $conn = new PDO("mysql:host=$servidor;dbname=$banco",$usuario, $senha);

}catch(PDOException $E){
    echo("Erro de conexao".$E->getMessage());
}

?>