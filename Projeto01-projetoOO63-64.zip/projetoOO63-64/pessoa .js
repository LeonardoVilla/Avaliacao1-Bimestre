class Pessoa{

    nome;
    idade;
    telefone;
    email;


    setNome(nome){
        this.nome = nome;
    }

    getNome(){
        return this.nome;
    }

    setIdade(idade){
        this.idade = idade;
    }

    getIdade(){
        return this.idade;
    }

    setTelefone(telefone){
        this.telefone = telefone;
    }

    getTelefone(){
        return this.telefone;
    }

    setEmail(email){
        this.email = email;
    }

    getEmail(){
        return this.email;
    }

}