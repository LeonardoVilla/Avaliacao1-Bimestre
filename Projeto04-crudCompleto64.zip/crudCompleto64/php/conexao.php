<?php
$servidor = "";
$banco = "crudcompleto";
$usuario = "";
$senha = "";
$cdn = "";

try{
    $conn = new PDO($cdn, $usuario, $senha);
    // echo "conectou";
}catch(PDOException $E){
    echo "Erro de conexao ".$E->getMessage();
}

?>