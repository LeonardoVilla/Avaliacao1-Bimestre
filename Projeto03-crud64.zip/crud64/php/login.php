<?php
    include('conexao.php');//abrindo a conexao com banco

    $usuario = $_POST['usuario'];
    $senha = $_POST['senha'];

    $sql = "SELECT * FROM tb_usuario WHERE usuario = '$usuario' 
                                            AND senha = '$senha'";

    try{
        $stmt = $conn->prepare($sql);//preparando o sql para ser excecutado
        $stmt->execute();//executando a consulta no banco

        $linhas = $stmt->rowCount();//verificando o nº linhas encontradas

        if($linhas > 0){ //verifica se encontrou ou não o usuario
            echo "Seja Bem-vindo ".$usuario;
            session_start();
            $_SESSION['usuario'] = $usuario;
            header("Location: ../home.php");
        }else{
            echo "Usuário ou senha inválidos";
        }

    }catch(PDOException $E){
        echo "SELECT INVÁLIDO ".$E->getMessage();//dispara erro se o select não funcionar
    }

?>