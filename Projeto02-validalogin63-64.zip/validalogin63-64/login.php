<?php
    include('conexao.php');

    $usuario = $_POST['email'];
    $senha = $_POST['senha'];

    $sql = "SELECT * FROM tb_usuario WHERE usuario ='$usuario' AND senha='$senha'";
        try{
        $stmt = $conn->prepare($sql);
        $stmt->execute();
        $linhas = $stmt->rowCount();
        if($linhas > 0){
            echo "Seja Bem-Vindo".$usuario;
            session_start();
            $_SESSION['usuario'] = $usuario;
        }else{
            echo "Usuário ou senha inválidos!";
        }
    }catch(PDOException $E){
        echo "ERROOO AO ACESSAR A TABELA USUARIO ".$E->getMessage();
    }

?>