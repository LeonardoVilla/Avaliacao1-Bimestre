<?php
$servidor = "localhost";
$usuario = "root";
$senha = "";
$banco = "bd_escola";

try{
    $conn = new PDO("mysql:host=$servidor;dbname=$banco",$usuario, 
                        $senha);
}catch(PDOException $E){
    echo "Erro ao conectar ".$E->getMessage();
}
?>